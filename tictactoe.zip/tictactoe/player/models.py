from django.db import models
from django.contrib.auth.models import User

class Invitation(models.Model):
    from_user = models.ForeignKey(User, related_name="invitation_sent", on_delete=models.CASCADE)
    to_user = models.ForeignKey(
        User, 
        related_name="invitations_received",
        verbose_name="User to invite",
        help_text="Please select user you want to play a game with",on_delete=models.CASCADE)
    message = models.CharField(
        max_length=300, blank=True,
        verbose_name="Optional Message",
        help_text="It's always a good idea to include a friendly message")

    timestamp = models.DateTimeField(auto_now_add=True)
# Create your models here.
